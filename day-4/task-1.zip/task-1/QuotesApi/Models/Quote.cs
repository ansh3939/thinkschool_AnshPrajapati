namespace QuotesApi.Models;

public class Quote
{
    public int Id { get; set; }
    public string Text { get; set; } = string.Empty;
    public string OwnerId { get; set; } = string.Empty;
}
